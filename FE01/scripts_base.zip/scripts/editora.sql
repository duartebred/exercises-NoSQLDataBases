insert into editora values (1, 'EMI');
insert into editora values (2, 'Sony');
insert into editora values (3, 'Valentim de Carvalho');
insert into editora values (4, 'Vevo');
insert into editora values (5, 'Apple');